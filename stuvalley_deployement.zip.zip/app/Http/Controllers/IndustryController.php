<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class IndustryController extends Controller
{
    private $industries = [
        'e-commerce-multi-vendor' => [
            'id' => 'e-commerce-multi-vendor',
            'title' => 'E-commerce & Retail',
            'hero_highlight' => 'Digital Commerce',
            'subtitle' => 'Scalable marketplaces and online stores that drive global sales.',
            'hero_image' => 'https://images.unsplash.com/photo-1556742049-0cfed4f7a07d?q=80&w=1600&auto=format&fit=crop',
            'about_image' => 'https://images.unsplash.com/photo-1556742205-e10c9486c506?q=80&w=800&auto=format&fit=crop',
            'trust_points' => ['High Conversion', 'Secure Payments', 'Omnichannel', 'Scalable'],
            'about_text' => 'We enable retailers to sell everywhere. From single-brand storefronts to complex multi-vendor marketplaces like Amazon, we build robust e-commerce ecosystems.',
            'features' => [
                ['title' => 'Multi-Vendor', 'desc' => 'Allow multiple sellers to register and sell products.', 'icon' => 'fa-store-alt'],
                ['title' => 'Payment Gateway', 'desc' => 'Integration with Stripe, PayPal, Razorpay, etc.', 'icon' => 'fa-credit-card'],
                ['title' => 'Inventory Mgmt', 'desc' => 'Real-time stock tracking across channels.', 'icon' => 'fa-box'],
                ['title' => 'Mobile App', 'desc' => 'Dedicated shopping apps for iOS and Android.', 'icon' => 'fa-mobile-alt'],
                ['title' => 'AI Recommendations', 'desc' => 'Personalized product suggestions.', 'icon' => 'fa-robot'],
                ['title' => 'Logistics Integration', 'desc' => 'Auto-shipping calculation and tracking.', 'icon' => 'fa-truck']
            ],
            'tech_stack' => ['Magento', 'Shopify', 'Laravel', 'React', 'AWS'],
            'process' => ['UX/UI Design', 'Platform Dev', 'Integration', 'Testing', 'Launch'],
            'benefits' => ['Global Reach', '24/7 Sales', 'Data Insights', 'Customer Loyalty'],
            'faq' => [
                ['q' => 'Can you build an app like Amazon?', 'a' => 'Yes, our multi-vendor solution has similar features.'],
                ['q' => 'Is it secure?', 'a' => 'We use PCI-DSS compliant standards for all transactions.']
            ]
        ],
        'real-estate-construction' => [
            'id' => 'real-estate-construction',
            'title' => 'Real Estate & Construction',
            'hero_highlight' => 'PropTech',
            'subtitle' => 'Transforming property management and sales with digital innovation.',
            'hero_image' => 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?q=80&w=1600&auto=format&fit=crop',
            'about_image' => 'https://images.unsplash.com/photo-1560518883-ce09059eeffa?q=80&w=800&auto=format&fit=crop',
            'trust_points' => ['Virtual Tours', 'CRM', 'Property Listings', 'Lead Gen'],
            'about_text' => 'The real estate industry is digital-first. We build portals, CRMs, and construction management tools that streamline operations and close deals faster.',
            'features' => [
                ['title' => 'Property Portal', 'desc' => 'Advanced search and filtering for listings.', 'icon' => 'fa-building'],
                ['title' => 'Virtual Tours', 'desc' => '360-degree walkthroughs and VR integration.', 'icon' => 'fa-vr-cardboard'],
                ['title' => 'Agent CRM', 'desc' => 'Manage leads and client communications.', 'icon' => 'fa-user-tie'],
                ['title' => 'Construction Mgmt', 'desc' => 'Track project timelines and budgets.', 'icon' => 'fa-hard-hat'],
                ['title' => 'Mortgage Calc', 'desc' => 'Built-in financial tools for buyers.', 'icon' => 'fa-calculator'],
                ['title' => 'Map Integration', 'desc' => 'Google Maps based property discovery.', 'icon' => 'fa-map-marked-alt']
            ],
            'tech_stack' => ['Laravel', 'Vue.js', 'Google Maps API', 'Matterport', 'AWS'],
            'process' => ['Blueprint', 'Design', 'Development', 'Integration', 'Support'],
            'benefits' => ['Faster Sales Cycle', 'Global Buyers', 'Operational Efficiency', 'Better CX'],
            'faq' => [
                ['q' => 'Do you support MLS integration?', 'a' => 'Yes, we can pull listings from major MLS databases.'],
                ['q' => 'Can we add 3D tours?', 'a' => 'Yes, we integrate with Matterport and other VR tools.']
            ]
        ],
        'travel-hospitality' => [
            'id' => 'travel-hospitality',
            'title' => 'Travel & Hospitality',
            'hero_highlight' => 'TravelTech',
            'subtitle' => 'Seamless booking experiences for the modern traveler.',
            'hero_image' => 'https://images.unsplash.com/photo-1469854523086-cc02fe5d8800?q=80&w=1600&auto=format&fit=crop',
            'about_image' => 'https://images.unsplash.com/photo-1520250497591-112f2f40a3f4?q=80&w=800&auto=format&fit=crop',
            'trust_points' => ['Booking Engine', 'GDS Integration', 'Mobile App', 'Loyalty'],
            'about_text' => 'We empower travel agencies, hotels, and airlines with robust booking engines and customer management systems to enhance the guest journey.',
            'features' => [
                ['title' => 'Booking Engine', 'desc' => 'Real-time flights, hotels, and tours booking.', 'icon' => 'fa-plane'],
                ['title' => 'GDS Integration', 'desc' => 'Connect with Amadeus, Sabre, and Travelport.', 'icon' => 'fa-globe'],
                ['title' => 'Itinerary Builder', 'desc' => 'Custom trip planning tools for users.', 'icon' => 'fa-route'],
                ['title' => 'Hotel PMS', 'desc' => 'Property management system for operations.', 'icon' => 'fa-hotel'],
                ['title' => 'Review System', 'desc' => 'User reviews and ratings integration.', 'icon' => 'fa-star'],
                ['title' => 'Loyalty Points', 'desc' => 'Reward programs for frequent travelers.', 'icon' => 'fa-passport']
            ],
            'tech_stack' => ['Node.js', 'React', 'Amadeus API', 'MySQL', 'Redis'],
            'process' => ['Scope', 'API Selection', 'Development', 'Testing', 'Launch'],
            'benefits' => ['Increased Bookings', 'Automated Ops', 'Global Inventory', 'Customer Retention'],
            'faq' => [
                ['q' => 'What APIs do you use?', 'a' => 'We work with Amadeus, Sabre, Expedia, and others.'],
                ['q' => 'Is it mobile friendly?', 'a' => 'Yes, travel booking is predominantly mobile-first.']
            ]
        ],
        'medical-healthcare' => [
            'id' => 'medical-healthcare',
            'title' => 'Medical & Healthcare',
            'hero_highlight' => 'HealthTech',
            'subtitle' => 'Secure, HIPAA-compliant digital solutions for better patient care.',
            'hero_image' => 'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?q=80&w=1600&auto=format&fit=crop',
            'about_image' => 'https://images.unsplash.com/photo-1584036561566-b93a58066c53?q=80&w=800&auto=format&fit=crop',
            'trust_points' => ['HIPAA Compliant', 'Telemedicine', 'EHR', 'Appointment Booking'],
            'about_text' => 'We bridge the gap between patients and providers. Our healthcare solutions improve accessibility, efficiency, and medical data security.',
            'features' => [
                ['title' => 'Telemedicine', 'desc' => 'Video consultation platforms.', 'icon' => 'fa-video-medical'],
                ['title' => 'EHR Systems', 'desc' => 'Electronic Health Records management.', 'icon' => 'fa-file-medical-alt'],
                ['title' => 'Practice Mgmt', 'desc' => 'Scheduling, billing, and administration.', 'icon' => 'fa-user-md'],
                ['title' => 'Patient Portal', 'desc' => 'Access lab results and prescriptions.', 'icon' => 'fa-procedures'],
                ['title' => 'Pharmacy App', 'desc' => 'Medicine ordering and delivery.', 'icon' => 'fa-pills'],
                ['title' => 'IoT Integration', 'desc' => 'Wearable data syncing.', 'icon' => 'fa-heartbeat']
            ],
            'tech_stack' => ['Laravel', 'React', 'WebRTC', 'AWS HIPAA', 'PostgreSQL'],
            'process' => ['Security Plan', 'UI/UX', 'Development', 'Audit', 'Go Live'],
            'benefits' => ['Remote Care', 'Paperless Ops', 'Better Outcomes', 'Data Security'],
            'faq' => [
                ['q' => 'Is it HIPAA compliant?', 'a' => 'Yes, all our healthcare apps adhere to strictly to HIPAA/GDPR.'],
                ['q' => 'Can you integrate video calls?', 'a' => 'Yes, we use secure WebRTC for high-quality video consultations.']
            ]
        ],
        'edtech-e-learning' => [
            'id' => 'edtech-e-learning',
            'title' => 'EdTech & Learning',
            'hero_highlight' => 'Future of Education',
            'subtitle' => 'Revolutionizing education with immersive digital learning platforms.',
            'hero_image' => 'https://images.unsplash.com/photo-1501504905252-473c47e087f8?q=80&w=1600&auto=format&fit=crop',
            'about_image' => 'https://images.unsplash.com/photo-1522202176988-66273c2fd55f?q=80&w=800&auto=format&fit=crop',
            'trust_points' => ['Smart Classroom', 'LMS', 'Gamification', 'Mobile Learning'],
            'about_text' => 'Education is evolving. We build platforms that make learning accessible, engaging, and measurable for schools, universities, and corporations.',
            'features' => [
                ['title' => 'LMS Development', 'desc' => 'Centralized learning management.', 'icon' => 'fa-graduation-cap'],
                ['title' => 'Live Classrooms', 'desc' => 'Interactive virtual sessions.', 'icon' => 'fa-chalkboard-teacher'],
                ['title' => 'Assessment', 'desc' => 'Online exams and automated grading.', 'icon' => 'fa-tasks'],
                ['title' => 'Gamification', 'desc' => 'Learning through badges and rewards.', 'icon' => 'fa-gamepad'],
                ['title' => 'School ERP', 'desc' => 'Management of students, staff, and fees.', 'icon' => 'fa-school'],
                ['title' => 'Mobile Learning', 'desc' => 'Learn anytime, anywhere.', 'icon' => 'fa-mobile']
            ],
            'tech_stack' => ['Moodle', 'Laravel', 'React', 'Zoom API', 'AWS'],
            'process' => ['Concept', 'Design', 'Core Dev', 'Pilot', 'Launch'],
            'benefits' => ['Global Access', 'Personalized Learning', 'Cost Efficiency', 'Scalability'],
            'faq' => [
                ['q' => 'Do you support Zoom?', 'a' => 'Yes, we integrate Zoom/Teams for live classes.'],
                ['q' => 'Can it scale to 10k students?', 'a' => 'Yes, our cloud architecture scales automatically.']
            ]
        ],
        'finance-insurance' => [
            'id' => 'finance-insurance',
            'title' => 'Finance & Insurance',
            'hero_highlight' => 'FinTech',
            'subtitle' => 'Secure, compliant, and innovative financial technology solutions.',
            'hero_image' => 'https://images.unsplash.com/photo-1563986768609-322da13575f3?q=80&w=1600&auto=format&fit=crop',
            'about_image' => 'https://images.unsplash.com/photo-1556742031-c6961e8560b0?q=80&w=800&auto=format&fit=crop',
            'trust_points' => ['Banking', 'Blockchain', 'InsurTech', 'Compliance'],
            'about_text' => 'Trust is the currency of finance. We build secure banking, payment, and insurance applications that protect assets and streamline transactions.',
            'features' => [
                ['title' => 'Digital Wallets', 'desc' => 'P2P payments and money storage.', 'icon' => 'fa-wallet'],
                ['title' => 'Loan Management', 'desc' => 'Origination, processing, and collection.', 'icon' => 'fa-hand-holding-usd'],
                ['title' => 'Crypto/Blockchain', 'desc' => 'Smart contracts and decentralized apps.', 'icon' => 'fa-bitcoin'],
                ['title' => 'Insurance Claims', 'desc' => 'Automated claim processing workflow.', 'icon' => 'fa-umbrella'],
                ['title' => 'KYC/AML', 'desc' => 'Identity verification integration.', 'icon' => 'fa-id-badge'],
                ['title' => 'Trading', 'desc' => 'Real-time stock/forex trading platforms.', 'icon' => 'fa-chart-line'],
            ],
            'tech_stack' => ['Java', 'Spring Boot', 'React', 'Blockchain', 'AWS'],
            'process' => ['Security First', 'Architecture', 'Compliance', 'Dev', 'Audit'],
            'benefits' => ['Fraud Reduction', 'Faster Transactions', 'Customer Trust', 'Compliance'],
            'faq' => [
                ['q' => 'How secure is it?', 'a' => 'We use banking-grade encryption and regular penetration testing.'],
                ['q' => 'Do you support blockchain?', 'a' => 'Yes, we have expertise in Ethereum and Hyperledger.']
            ]
        ],
        'manufacturing' => [
            'id' => 'manufacturing',
            'title' => 'Manufacturing',
            'hero_highlight' => 'Industry 4.0',
            'subtitle' => 'Smart manufacturing solutions for the connected factory.',
            'hero_image' => 'https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?q=80&w=1600&auto=format&fit=crop',
            'about_image' => 'https://images.unsplash.com/photo-1581093458791-9f3c3900df4b?q=80&w=800&auto=format&fit=crop',
            'trust_points' => ['IoT', 'Supply Chain', 'Predictive Maint', 'Automation'],
            'about_text' => 'Optimize production with digital twins, IoT, and data analytics. We help manufacturers embrace Industry 4.0 for higher efficiency and lower downtime.',
            'features' => [
                ['title' => 'IoT Monitoring', 'desc' => 'Real-time sensor data from machines.', 'icon' => 'fa-microchip'],
                ['title' => 'Supply Chain', 'desc' => 'End-to-end visibility of materials.', 'icon' => 'fa-pallet'],
                ['title' => 'ERP for Mfg', 'desc' => 'Resource planning specialized for factories.', 'icon' => 'fa-cogs'],
                ['title' => 'Predictive Maint', 'desc' => 'AI to predict machine failures.', 'icon' => 'fa-wrench'],
                ['title' => 'Quality Control', 'desc' => 'Automated inspection systems.', 'icon' => 'fa-check-double'],
                ['title' => 'Warehouse Mgmt', 'desc' => 'Barcode/RFID inventory tracking.', 'icon' => 'fa-warehouse']
            ],
            'tech_stack' => ['Python', 'IoT', 'Azure Digital Twins', 'Angular', 'DotNet'],
            'process' => ['Assessment', 'Sensor Setup', 'Cloud Integration', 'Analytics', 'Scale'],
            'benefits' => ['Reduced Downtime', 'Higher Output', 'Lower Waste', 'Data Driven'],
            'faq' => [
                ['q' => 'What IoT protocols?', 'a' => 'We work with MQTT, OPC-UA, and Modbus.'],
                ['q' => 'Can you connect old machines?', 'a' => 'Yes, we use retrofitting sensors to digitize legacy equipment.']
            ]
        ]
    ];

    public function index()
    {
        $industries = json_decode(json_encode($this->industries));
        return view('industries.index', compact('industries'));
    }

    public function show($slug)
    {
        if (!array_key_exists($slug, $this->industries)) {
            abort(404);
        }

        $service = (object) $this->industries[$slug];

        $service->features = json_decode(json_encode($service->features));
        $service->faq = json_decode(json_encode($service->faq ?? []));

        return view('service_detail', compact('service'));
    }
}
