<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Schema;
use App\Models\Setting;
use App\Models\SocialLink;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        if (Schema::hasTable('settings')) {
            $settings = Setting::all()->pluck('value', 'key')->toArray();
            View::share('global_settings', $settings);
        }

        View::composer('*', function ($view) {
            if (Schema::hasTable('social_links')) {
                $view->with('global_social_links', SocialLink::where('is_active', true)->get());
            }
            if (Schema::hasTable('solutions')) {
                $view->with('global_solutions', \App\Models\Solution::where('is_active', true)->get());
            }
        });
    }
}
