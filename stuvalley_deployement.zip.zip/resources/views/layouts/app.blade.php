<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <script>document.documentElement.classList.add('js-enabled');</script>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    @php
        // Determine current page ID based on route name or URI
        $current_route = Route::currentRouteName();
        $page_id = 'home'; // default
        if ($current_route == 'about')
            $page_id = 'about';
        if ($current_route == 'services.index')
            $page_id = 'services';
        if ($current_route == 'services.show')
            $page_id = 'services-' . request('slug'); // dynamic services
        // ... add more logic for contact etc.

        // Fetch SEO data directly (since we didn't add a Composer yet, this is direct injection for speed)
        $seo_meta = \App\Models\SeoPage::where('page_identifier', $page_id)->first();
    @endphp

    <title>
        {{ $seo_meta->title ?? $global_settings['seo_home_title'] ?? 'Stuvalley Technology - Empowering Digital Innovation' }}
    </title>
    <meta name="description"
        content="{{ $seo_meta->description ?? $global_settings['seo_home_desc'] ?? 'Stuvalley Technology delivers cutting-edge solutions in academia, research, training, and recruitment.' }}">
    <meta name="keywords" content="{{ $seo_meta->keywords ?? '' }}">

    <!-- Open Graph / Social Media -->
    <meta property="og:title" content="{{ $seo_meta->title ?? 'Stuvalley Technology' }}">
    <meta property="og:description" content="{{ $seo_meta->description ?? '' }}">
    @if(isset($seo_meta->image))
        <meta property="og:image" content="{{ asset('storage/' . $seo_meta->image) }}">
    @endif
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Manrope:wght@300;400;500;600;700;800&family=Outfit:wght@300;400;500;600;700;800&family=Playfair+Display:ital,wght@0,400;0,700;1,400&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="icon" href="{{ asset('favicon.jpg') }}?v={{ time() }}" type="image/jpeg">
    <style>
        body,
        html {
            background-color: #000 !important;
            margin: 0;
            padding: 0;
            overflow-x: hidden;
            font-family: 'Manrope', sans-serif;
        }

        .contact-section {
            margin-bottom: 0 !important;
            padding-bottom: 20px !important;
        }

        footer {
            margin-top: 0 !important;
        }

        /* Fix for any white gaps */
        section {
            margin-bottom: 0 !important;
        }

        .whatsapp-float {
            position: fixed;
            bottom: 40px;
            right: 40px;
            width: 65px;
            height: 65px;
            background: linear-gradient(135deg, #25d366 0%, #128c7e 100%);
            color: #fff;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 32px;
            box-shadow: 0 10px 25px rgba(37, 211, 102, 0.4);
            z-index: 10000;
            text-decoration: none;
            transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            border: 2px solid rgba(255, 255, 255, 0.1);
        }

        .whatsapp-float:hover {
            transform: scale(1.1) translateY(-5px);
            background: linear-gradient(135deg, #128c7e 0%, #25d366 100%);
            box-shadow: 0 15px 35px rgba(37, 211, 102, 0.6);
            color: #fff;
        }

        .whatsapp-float i {
            animation: pulse-wa 2s infinite;
        }

        @keyframes pulse-wa {
            0% {
                transform: scale(1);
            }

            50% {
                transform: scale(1.1);
            }

            100% {
                transform: scale(1);
            }
        }

        /* Premium Navbar Icons */
        .nav-icon {
            margin-right: 8px;
            font-size: 0.9em;
            color: inherit;
            transition: all 0.3s ease;
            opacity: 0.85;
        }

        .nav-links a:hover .nav-icon,
        .dropbtn:hover .nav-icon {
            color: #3b82f6;
            transform: scale(1.1);
            text-shadow: 0 0 10px rgba(59, 130, 246, 0.4);
            opacity: 1;
        }

        @media (max-width: 992px) {
            .nav-icon {
                margin-right: 12px;
                font-size: 1.1em;
            }
        }

        /* Fix Navbar Alignment - Icon & Text always inline */
        .nav-links li a,
        .dropbtn {
            display: flex !important;
            align-items: center;
            gap: 5px;
            /* Ensure small gap if margin fails */
        }
    </style>
    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>

<body>
    <!-- Tech Loader -->
    <!-- Tech Loader (Disabled for debugging) -->
    <div id="tech-loader">
        <div class="loader-content">
            <div class="tech-circle-outer"></div>
            <div class="tech-circle-inner"></div>
            <div class="tech-text">INITIALIZING...</div>
        </div>
    </div>
    <!-- Top Bar -->
    <div class="top-bar">
        <div class="container tb-flex">
            <div class="tb-contact">
                <span><img src="https://flagcdn.com/w20/in.png" alt="India">
                    {{ $global_settings['phone_india'] ?? '+91 7292 050505' }}</span>
                <span><i class="fas fa-envelope" style="color: #F4C430;"></i> {{ $global_settings['email_primary'] ??
                    'hello@stuvalley.com' }}</span>
            </div>
            <div class="tb-social">
                @if(isset($global_social_links))
                    @foreach($global_social_links as $link)
                        <a href="{{ $link->url }}" target="_blank" title="{{ $link->platform }}"><i
                                class="{{ $link->icon }}"></i></a>
                    @endforeach
                @endif
            </div>
        </div>
    </div>
    <header class="@yield('header_class')">
        <div class="container-fluid"
            style="width: 100%; padding: 0 40px; display: flex; justify-content: space-between; align-items: center;">
            <nav>
                <a href="/" class="logo">
                    @if(isset($global_settings['site_logo']))
                        <img src="{{ asset('storage/' . $global_settings['site_logo']) }}"
                            alt="Stuvalley Technology Pvt. Ltd.">
                    @else
                        <img src="{{ asset('images/stuvalley_logo.png') }}" alt="Stuvalley Technology Pvt. Ltd.">
                    @endif
                </a>
                <div class="nav-links-wrapper">
                    <ul class="nav-links">
                        <li><a href="/"><i class="fas fa-home nav-icon"></i> HOME</a></li>
                        <li><a href="/about"><i class="fas fa-user-circle nav-icon"></i> ABOUT</a></li>
                        <li class="dropdown">
                            <a href="{{ route('services.index') }}" class="dropbtn"><i
                                    class="fas fa-briefcase nav-icon"></i> SERVICES <span class="nav-arrow">▼</span></a>
                            <ul class="dropdown-content">
                                <li><a href="{{ route('services.show', 'web-development') }}">Web Development</a></li>
                                <li><a href="{{ route('services.show', 'mobile-app-development') }}">Mobile App
                                        Development</a></li>
                                <li><a href="{{ route('services.show', 'seo-services') }}">SEO Services</a></li>
                            </ul>
                        </li>
                        <li class="dropdown">
                            <a href="#industries" class="dropbtn"><i class="fas fa-layer-group nav-icon"></i> INDUSTRIES
                                <span class="nav-arrow">▼</span></a>
                            <ul class="dropdown-content">
                                <li><a href="{{ route('industries.show', 'e-commerce-multi-vendor') }}">E-commerce &
                                        Multi-Vendor</a></li>
                                <li><a href="{{ route('industries.show', 'edtech-e-learning') }}">EdTech &
                                        E-Learning</a></li>
                                <li><a href="{{ route('industries.show', 'medical-healthcare') }}">Medical &
                                        Healthcare</a></li>
                                <li><a href="{{ route('industries.show', 'real-estate-construction') }}">Real Estate &
                                        Construction</a></li>
                                <li><a href="{{ route('industries.show', 'travel-hospitality') }}">Travel &
                                        Hospitality</a></li>
                            </ul>
                        </li>
                        <li><a href="#contact"><i class="fas fa-envelope nav-icon"></i> CONTACT</a></li>
                    </ul>
                </div>
                <div class="cta-btn-wrapper">
                    <a href="#contact" class="cta-btn">GET A FREE CONSULTATION!</a>
                </div>
            </nav>
        </div>
    </header>

    <main>
        @yield('content')
    </main>

    <!-- Premium Enterprise-Grade Footer -->
    <footer id="main-footer">
        <div class="footer-glow"></div>
        <div class="footer-border-top"></div>

        <div class="container" style="max-width: 1400px; padding: 0 10px; z-index: 2; position: relative;">

            <!-- Top Section: 3-Col Layout -->
            <div class="footer-top-grid">

                <!-- 1. Brand & Identity (Balanced) -->
                <!-- 1. Brand & Identity (Balanced) -->
                <div class="ft-col-brand">
                    <a href="/" class="ft-logo">
                        @if(isset($global_settings['site_logo']))
                            <img src="{{ asset('storage/' . $global_settings['site_logo']) }}" alt="Stuvalley"
                                style="height: 50px; width: auto; filter: brightness(0) invert(1);">
                        @else
                            <img src="{{ asset('images/stuvalley_logo.png') }}" alt="Stuvalley"
                                style="height: 50px; width: auto; filter: brightness(0) invert(1);">
                        @endif
                    </a>

                    <div class="tagline-wrapper">
                        <p class="ft-tagline">Transforming idea to e-nnovation</p>
                        <div class="tagline-accent"></div>
                    </div>

                    <!-- Partner Logos -->
                    <div class="ft-partners-row">
                        <i class="fab fa-google" title="Google Partner"></i>
                        <i class="fab fa-meta" title="Meta Business Partner"></i>
                        <i class="fas fa-ad" title="Google Ads"></i> <!-- Using generic ad icon or text -->
                        <i class="fab fa-shopify" title="Shopify Partner"></i>
                    </div>

                    <!-- Trusted By Badge -->
                    <div class="trusted-badge-enhanced">
                        <span class="tb-label">TRUSTED BY LEADING COMPANIES</span>
                        <div class="tb-logos">
                            @php
                                $footer_partners = \App\Models\Partner::where('is_active', true)->orderBy('sort_order')->take(4)->get();
                            @endphp
                            @foreach($footer_partners as $partner)
                                @if(Str::startsWith($partner->logo, 'http'))
                                    <img src="{{ $partner->logo }}" alt="{{ $partner->name }}">
                                @else
                                    <img src="{{ asset('storage/' . $partner->logo) }}" alt="{{ $partner->name }}">
                                @endif
                            @endforeach
                        </div>
                    </div>
                </div>

                <!-- 2. Interactive Contact Card (Refined Spacing) -->
                <div class="ft-col-contact">
                    <div class="glass-card contact-card">
                        <h4 class="card-heading">Contact Us</h4>

                        <ul class="contact-list">
                            <li>
                                <a href="mailto:{{ $global_settings['email_support'] ?? 'info@stuvalley.com' }}">
                                    <div class="c-icon"><i class="fas fa-envelope"></i></div>
                                    <span>{{ $global_settings['email_support'] ?? 'info@stuvalley.com' }}</span>
                                </a>
                            </li>
                            <li>
                                <a href="{{ $global_settings['website_url'] ?? '#' }}">
                                    <div class="c-icon"><i class="fas fa-globe"></i></div>
                                    <span>{{ $global_settings['website_url'] ?? 'www.stuvalley.com' }}</span>
                                </a>
                            </li>
                            <li>
                                <div class="c-item">
                                    <div class="c-icon"><i class="fas fa-map-marker-alt"></i></div>
                                    <span
                                        class="address-text">{!! e($global_settings['address_india'] ?? 'M 13, Sector 14, near SBI, Block M, Old DLF, Gurugram, India') !!}</span>
                                </div>
                            </li>
                            <li>
                                <a href="tel:{{ $global_settings['phone_india_landline'] ?? '0124-4252-196' }}">
                                    <div class="c-icon"><i class="fas fa-phone-alt"></i></div>
                                    <span>{{ $global_settings['phone_india_landline'] ?? '0124-4252-196' }}</span>
                                </a>
                            </li>
                        </ul>

                        <div class="mini-cta">
                            <span>Let’s discuss your project</span>
                            <a href="#contact" class="btn-mini-tech">Get Quote <i class="fas fa-arrow-right"></i></a>
                        </div>

                        <div class="social-row">
                            @if(isset($global_social_links))
                                @foreach($global_social_links as $link)
                                    <a href="{{ $link->url }}" target="_blank" class="s-btn"><i
                                            class="{{ $link->icon }}"></i></a>
                                @endforeach
                            @endif
                        </div>
                    </div>
                </div>

                <!-- 3. Tech Map Card (Centered Title) -->
                <div class="ft-col-map">
                    <div class="glass-card map-card">
                        <div class="map-header">
                            <i class="fas fa-map-pin map-pin-anim"></i>
                            <span class="map-title-text">Find Us on Google Maps</span>
                        </div>
                        <div class="map-frame-wrapper">
                            <iframe
                                src="{{ $global_settings['google_map_embed'] ?? 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d14030.765692019864!2d77.0456187!3d28.4713915!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390d190479d5057d%3A0xe54eaf95542289!2zTCAxMywgU2VjdG9yIDE0LCBHdXJ1Z3JhbSwgSGFyeWFuYSAxMjIwMDE!5e0!3m2!1sen!2sin!4v1706256000000!5m2!1sen!2sin' }}"
                                allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade">
                            </iframe>
                            <!-- Removed overlay to keep map fully interactive and bright -->
                        </div>
                    </div>
                </div>
            </div>

            <!-- Links Grid: 4 Columns -->
            <div class="footer-links-grid">
                <!-- Col 1 -->
                <div class="fl-col">
                    <h5>SERVICES</h5>
                    <ul>
                        <li><a href="{{ route('services.show', 'web-development') }}">Web Development</a></li>
                        <li><a href="{{ route('services.show', 'mobile-app-development') }}">Mobile App Development</a>
                        </li>
                        <li><a href="{{ route('services.show', 'custom-application') }}">Custom Application</a></li>
                        <li><a href="{{ route('services.show', 'web-design') }}">Web Design</a></li>
                        <li><a href="{{ route('services.show', 'brand-design') }}">Brand Design</a></li>
                        <li><a href="{{ route('services.show', 'api-development') }}">API Development</a></li>
                        <li><a href="{{ route('services.show', 'saas-application') }}">SaaS Application</a></li>
                        <li><a href="{{ route('services.show', 'seo-services') }}">SEO Services</a></li>
                    </ul>
                </div>
                <!-- Col 2 -->
                <div class="fl-col">
                    <h5>SOLUTIONS</h5>
                    <ul>
                        <li><a href="{{ route('solutions.show', 'erp-solution') }}">ERP Solution</a></li>
                        <li><a href="{{ route('solutions.show', 'cms-solution') }}">CMS Solution</a></li>
                        <li><a href="{{ route('solutions.show', 'crm-solution') }}">CRM Solution</a></li>
                        <li><a href="{{ route('solutions.show', 'lms-solution') }}">LMS Solution</a></li>
                        <li><a href="{{ route('solutions.show', 'hrm-solution') }}">HRM Solution</a></li>
                        <li><a href="{{ route('solutions.show', 'pos-solution') }}">POS Solution</a></li>
                    </ul>
                </div>
                <!-- Col 3 -->
                <div class="fl-col">
                    <h5>INDUSTRIES</h5>
                    <ul>
                        <li><a href="{{ route('industries.show', 'e-commerce-multi-vendor') }}">E-commerce &
                                Multi-Vendor</a></li>
                        <li><a href="{{ route('industries.show', 'real-estate-construction') }}">Real Estate &
                                Construction</a></li>
                        <li><a href="{{ route('industries.show', 'travel-hospitality') }}">Travel & Hospitality</a></li>
                        <li><a href="{{ route('industries.show', 'medical-healthcare') }}">Medical & Healthcare</a></li>
                        <li><a href="{{ route('industries.show', 'edtech-e-learning') }}">EdTech & E-Learning</a></li>
                        <li><a href="{{ route('industries.show', 'finance-insurance') }}">Finance & Insurance</a></li>
                        <li><a href="{{ route('industries.show', 'manufacturing') }}">Manufacturing</a></li>
                    </ul>
                </div>
                <!-- Col 4 -->
                <div class="fl-col">
                    <h5>COMPANY</h5>
                    <ul>
                        <li><a href="{{ route('about') }}">About Us</a></li>
                        <li><a href="{{ route('contact') }}">Contact Us</a></li>
                        <li><a href="{{ route('careers') }}">Careers</a></li>
                        <li><a href="{{ route('blog') }}">Blog</a></li>
                        <li><a href="{{ route('privacy') }}">Privacy Policy</a></li>
                        <li><a href="{{ route('terms') }}">Terms of Service</a></li>
                    </ul>
                </div>
            </div>

            <!-- Footer Bottom Bar (Polished) -->
            <div class="footer-bottom-bar">
                <div class="copyright-text">
                    &copy; 2026 Stuvalley Technology Pvt Ltd. All rights reserved.
                </div>
                <div class="secure-payments">
                    <span>Secure Payments</span>
                    <div class="pay-icons">
                        <i class="fab fa-cc-visa"></i>
                        <i class="fab fa-cc-mastercard"></i>
                        <i class="fab fa-cc-paypal"></i>
                        <i class="fab fa-stripe"></i>
                    </div>
                </div>
            </div>
        </div>

        <style>
            /* --- FOOTER MAIN STYLES --- */
            #main-footer {
                background: linear-gradient(180deg, #0a0a0d 0%, #000000 100%);
                position: relative;
                padding: 100px 0 0;
                overflow: hidden;
                font-family: 'Manrope', sans-serif;
                color: #e2e8f0;
            }

            .footer-glow {
                position: absolute;
                top: -300px;
                left: 50%;
                transform: translateX(-50%);
                width: 1200px;
                height: 800px;
                background: radial-gradient(circle, rgba(59, 130, 246, 0.06) 0%, transparent 60%);
                pointer-events: none;
                z-index: 1;
            }

            .footer-border-top {
                position: absolute;
                top: 0;
                left: 0;
                width: 100%;
                height: 1px;
                background: linear-gradient(90deg, transparent 0%, rgba(59, 130, 246, 0.5) 50%, transparent 100%);
                box-shadow: 0 0 10px rgba(59, 130, 246, 0.3);
            }

            /* --- TOP GRID --- */
            .footer-top-grid {
                display: grid;
                grid-template-columns: 1.2fr 1fr 1fr;
                gap: 40px;
                /* Reduced gap */
                margin-bottom: 80px;
            }

            /* 1. BRAND COL (Improved) */
            .ft-col-brand .ft-logo img {
                filter: brightness(1.3);
                /* Boost brightness */
            }

            .ft-tagline {
                font-family: 'Playfair Display', serif;
                font-style: italic;
                font-size: 1.6rem;
                /* Increased size */
                color: #ffffff;
                margin: 0;
                margin-top: 20px;
                line-height: 1.3;
            }

            .tagline-accent {
                width: 70px;
                height: 3px;
                background: linear-gradient(90deg, #3b82f6, #06b6d4);
                margin-top: 15px;
                /* Spacing */
                margin-bottom: 35px;
                border-radius: 2px;
                box-shadow: 0 0 8px rgba(59, 130, 246, 0.5);
                /* Glow */
            }

            .ft-partners-row {
                display: flex;
                gap: 25px;
                align-items: center;
                margin-bottom: 40px;
            }

            .ft-partners-row img,
            .ft-partners-row i {
                height: 24px;
                width: auto;
                text-align: center;
                filter: grayscale(100%) opacity(0.6);
                transition: all 0.4s ease;
                cursor: pointer;
            }

            .ft-partners-row i {
                font-size: 24px;
                color: #fff;
            }

            .ft-partners-row img:hover,
            .ft-partners-row i:hover {
                filter: grayscale(0%) opacity(1);
                transform: scale(1.1);
            }

            .ft-partners-row i:hover {
                color: #96bf48;
                /* Shopify Green */
            }

            .trusted-badge-enhanced {
                display: inline-flex;
                flex-direction: column;
                gap: 12px;
                padding: 16px 20px;
                background: rgba(255, 255, 255, 0.03);
                border: 1px solid rgba(255, 255, 255, 0.08);
                border-radius: 12px;
                backdrop-filter: blur(5px);
            }

            .tb-label {
                font-size: 0.65rem;
                font-weight: 700;
                color: #64748b;
                letter-spacing: 1.5px;
                text-transform: uppercase;
            }

            .tb-logos {
                display: flex;
                gap: 20px;
                align-items: center;
            }

            .tb-logos img {
                height: 20px;
                width: auto;
                filter: grayscale(100%) invert(1) brightness(0.7);
                opacity: 0.7;
                transition: 0.3s;
            }

            .tb-logos img:hover {
                filter: grayscale(0%);
                opacity: 1;
            }

            /* 2. CONTACT CARD (Refined) */
            .glass-card {
                background: rgba(20, 20, 25, 0.6);
                backdrop-filter: blur(14px);
                border: 1px solid rgba(255, 255, 255, 0.08);
                border-radius: 20px;
                padding: 35px 30px;
                /* More padding */
                box-shadow: 0 20px 40px rgba(0, 0, 0, 0.4);
                transition: transform 0.4s ease, border-color 0.4s ease;
                display: flex;
                /* Ensure stretch */
                flex-direction: column;
            }

            .glass-card:hover {
                transform: translateY(-5px);
                border-color: rgba(59, 130, 246, 0.5);
                background: rgba(15, 15, 20, 0.95) !important;
                /* Force Dark Theme */
                box-shadow: 0 25px 50px rgba(0, 0, 0, 0.5);
            }

            .card-heading {
                font-size: 1.1rem;
                font-weight: 700;
                color: #fff;
                margin-bottom: 25px;
                letter-spacing: 0.5px;
                text-transform: uppercase;
            }

            .contact-list {
                list-style: none;
                padding: 0;
                margin: 0;
            }

            .contact-list li {
                margin-bottom: 22px;
                /* Increased Spacing */
            }

            .contact-list a,
            .contact-list .c-item {
                display: flex;
                align-items: center;
                /* Perfect vertical center */
                gap: 18px;
                /* More gap */
                color: #bdc5d1;
                text-decoration: none;
                font-size: 0.95rem;
                transition: color 0.3s ease;
            }

            .contact-list a:hover {
                color: #fff;
            }

            .c-icon {
                width: 38px;
                height: 38px;
                background: linear-gradient(135deg, rgba(59, 130, 246, 0.1), rgba(6, 182, 212, 0.1));
                border-radius: 50%;
                display: flex;
                align-items: center;
                justify-content: center;
                color: #3b82f6;
                font-size: 0.9rem;
                border: 1px solid rgba(59, 130, 246, 0.2);
                flex-shrink: 0;
                transition: 0.3s;
            }

            .contact-list li:hover .c-icon {
                background: linear-gradient(135deg, #3b82f6, #06b6d4);
                color: #fff;
                box-shadow: 0 0 15px rgba(59, 130, 246, 0.4);
                transform: scale(1.1);
            }

            .address-text {
                line-height: 1.7;
                /* Increased line-height */
                font-size: 0.9rem;
            }

            .mini-cta {
                margin-top: auto;
                /* Push to bottom if space allows */
                padding-top: 25px;
                border-top: 1px solid rgba(255, 255, 255, 0.1);
                display: flex;
                justify-content: space-between;
                align-items: center;
            }

            .mini-cta span {
                font-size: 0.85rem;
                color: #94a3b8;
                font-weight: 600;
            }

            .btn-mini-tech {
                font-size: 0.8rem;
                font-weight: 700;
                color: #fff;
                background: linear-gradient(90deg, #3b82f6, #2563eb);
                padding: 8px 18px;
                border-radius: 30px;
                text-decoration: none;
                transition: 0.3s;
                box-shadow: 0 4px 12px rgba(37, 99, 235, 0.3);
            }

            .btn-mini-tech:hover {
                background: linear-gradient(90deg, #2563eb, #1d4ed8);
                transform: translateX(3px);
            }

            /* 3. SOCIAL ICONS (Improved) */
            .social-row {
                display: flex;
                gap: 12px;
                margin-top: 25px;
            }

            .s-btn {
                width: 42px;
                /* Uniform Size */
                height: 42px;
                border: 1px solid rgba(255, 255, 255, 0.1);
                border-radius: 50%;
                display: flex;
                align-items: center;
                justify-content: center;
                color: #fff;
                transition: 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
                font-size: 1rem;
                opacity: 0.7;
                /* Default transparency */
                background: rgba(255, 255, 255, 0.02);
            }

            .s-btn:hover {
                opacity: 1;
                transform: scale(1.1);
                /* Scale Effect */
                border-color: #3b82f6;
                box-shadow: 0 0 15px rgba(59, 130, 246, 0.4);
                /* Glow */
                background: rgba(59, 130, 246, 0.1);
            }

            /* 4. MAP CARD (Centered Title) */
            .map-card {
                height: 100%;
                min-height: 450px;
                display: flex;
                flex-direction: column;
                align-items: stretch;
                /* Ensure children fill width */
                padding: 5% 10%;
                /* Full bleed */
                overflow: hidden;
                border-radius: 24px;
                transition: all 0.6s cubic-bezier(0.165, 0.84, 0.44, 1);
                border: 1px solid rgba(255, 255, 255, 0.05);
                width: 85% !important;
                margin: 0 auto !important;
            }

            .map-card:hover {
                padding: 5% 10%;
                /* Full bleed on hover too */
                transform: translateY(-5px) scale(1.02);
                border-color: rgba(59, 130, 246, 0.5);
                background: rgba(15, 15, 20, 0.98) !important;
                box-shadow: 0 30px 60px rgba(0, 0, 0, 0.6);
            }

            .map-header {
                width: 100%;
                padding: 20px 25px;
                background: rgba(0, 0, 0, 0.3);
                border-bottom: 1px solid rgba(255, 255, 255, 0.1);
                display: flex;
                align-items: center;
                justify-content: center;
                /* Centered */
                gap: 12px;
                border-radius: 12px 12px 0 0;
            }

            .map-title-text {
                font-size: 0.95rem;
                font-weight: 700;
                color: #fff;
                letter-spacing: 0.5px;
            }

            .map-pin-anim {
                color: #f43f5e;
                animation: bounce 2s infinite;
            }

            .map-frame-wrapper {
                width: 100%;
                flex-grow: 1;
                position: relative;
                border-radius: 0 0 12px 12px;
                overflow: hidden;
                border: none;
            }

            .map-frame-wrapper iframe {
                width: 100%;
                height: 100%;
                border: 0;
            }

            @keyframes bounce {

                0%,
                100% {
                    transform: translateY(0);
                }

                50% {
                    transform: translateY(-5px);
                }
            }

            /* --- FOOTER LINKS GRID --- */
            .footer-links-grid {
                display: grid;
                grid-template-columns: repeat(4, 1fr);
                gap: 40px;
                margin-bottom: 80px;
            }

            .fl-col h5 {
                font-size: 0.85rem;
                font-weight: 800;
                color: #fff;
                letter-spacing: 1.2px;
                margin-bottom: 25px;
                position: relative;
                display: inline-block;
            }

            .fl-col h5::after {
                content: '';
                position: absolute;
                left: 0;
                bottom: -8px;
                width: 25px;
                height: 2px;
                background: #3b82f6;
            }

            .fl-col ul {
                list-style: none;
                padding: 0;
                margin: 0;
            }

            .fl-col ul li {
                margin-bottom: 14px;
            }

            .fl-col ul li a {
                color: #94a3b8;
                text-decoration: none;
                font-size: 0.95rem;
                transition: all 0.3s;
                display: flex;
                align-items: center;
                position: relative;
                overflow: hidden;
            }

            .fl-col ul li a::before {
                content: '→';
                position: absolute;
                left: -20px;
                opacity: 0;
                transition: 0.3s;
                color: #3b82f6;
                font-size: 0.9rem;
            }

            .fl-col ul li a:hover {
                color: #fff;
                padding-left: 20px;
            }

            .fl-col ul li a:hover::before {
                left: 0;
                opacity: 1;
            }

            /* --- BOTTOM BAR --- */
            .footer-bottom-bar {
                border-top: 1px solid rgba(255, 255, 255, 0.08);
                /* Divider */
                padding: 30px 0 50px;
                display: flex;
                justify-content: space-between;
                align-items: center;
                flex-wrap: wrap;
                gap: 20px;
            }

            .copyright-text {
                font-size: 0.9rem;
                color: #64748b;
                font-weight: 500;
            }

            .secure-payments {
                display: flex;
                align-items: center;
                gap: 15px;
            }

            .secure-payments span {
                font-size: 0.8rem;
                font-weight: 600;
                color: #64748b;
                text-transform: uppercase;
                letter-spacing: 1px;
            }

            .pay-icons i {
                font-size: 1.5rem;
                color: #94a3b8;
                margin-left: 10px;
                transition: 0.3s;
            }

            .pay-icons i:hover {
                color: #fff;
                transform: scale(1.1);
            }

            /* --- RESPONSIVE --- */
            @media (max-width: 1024px) {
                .footer-top-grid {
                    grid-template-columns: 1fr 1fr;
                }

                .ft-col-map {
                    grid-column: 1 / -1;
                    min-height: 300px;
                }
            }

            @media (max-width: 768px) {
                .footer-top-grid {
                    grid-template-columns: 1fr;
                    gap: 40px;
                }

                .footer-links-grid {
                    grid-template-columns: 1fr 1fr;
                }
            }

            @media (max-width: 480px) {
                .footer-links-grid {
                    grid-template-columns: 1fr;
                }

                .footer-bottom-bar {
                    justify-content: center;
                    text-align: center;
                }
            }
        </style>
    </footer>

    <!-- WhatsApp Floating Button -->
    @php
        $whatsapp_number = $global_settings['contact_whatsapp'] ?? '917292050505'; // Fallback to provided contact
        // Remove non-numeric characters
        $wa_number = preg_replace('/[^0-9]/', '', $whatsapp_number);

        // If number is 10 digits (common in India), prepend 91
        if (strlen($wa_number) == 10) {
            $wa_number = '91' . $wa_number;
        }

        $wa_msg = $global_settings['contact_whatsapp_msg'] ?? 'Hello, I am interested in your services.';
        $wa_url = "https://wa.me/{$wa_number}";
        if (!empty($wa_msg)) {
            $wa_url .= "?text=" . urlencode($wa_msg);
        }
    @endphp

    <a href="{{ $wa_url }}" class="whatsapp-float" target="_blank" title="Chat with us on WhatsApp">
        <i class="fab fa-whatsapp"></i>
    </a>

    <!-- Lenis Smooth Scroll -->
    <script src="https://cdn.jsdelivr.net/gh/studio-freight/lenis@1.0.29/bundled/lenis.min.js"></script>

    <script>
        // Header Scroll Effect
        const header = document.querySelector('header');
        const logoImg = document.querySelector('.logo img');

        window.addEventListener('scroll', () => {
            if (window.scrollY > 50) {
                header.classList.add('scrolled');
            } else {
                header.classList.remove('scrolled');
            }
        });

        // Initial check
        if (window.scrollY > 50) {
            header.classList.add('scrolled');
        }
    </script>
</body>

</html>